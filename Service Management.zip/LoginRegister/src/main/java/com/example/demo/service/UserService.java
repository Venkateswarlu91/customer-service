package com.example.demo.service;

import com.example.demo.model.User;
import java.util.List;

public interface UserService {
    String register(User user);
    User login(String email, String password);
    User findById(int id);
    User updateUser(User user);
    void deleteUser(int id);
    List<User> findAllUsers(); // New method to retrieve all users
}
