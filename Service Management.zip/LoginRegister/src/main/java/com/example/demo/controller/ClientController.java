package com.example.demo.controller;



import com.example.demo.model.User;

import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ClientController {

	

	
	
    @Autowired
    private UserService userService;

    @GetMapping("/")
    public ModelAndView login(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("login");
        return mv;
    }

    @GetMapping("/register")
    public ModelAndView register(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("register");
        return mv;
    }

    @PostMapping("/registerprocess")
    public ModelAndView add(HttpServletRequest request) {
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String address = request.getParameter("address");

        User s = new User();
        s.setAddress(address);
        s.setEmail(email);
        s.setName(name);
        s.setPassword(password);

        String str = userService.register(s);
        ModelAndView mv = new ModelAndView("login");
        mv.addObject("msg", str);
        return mv;
    }

    @PostMapping("/loginprocess")
    public ModelAndView userlogin(HttpServletRequest request) {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User tmp = userService.login(email, password);

        if (tmp == null) {
            ModelAndView mv = new ModelAndView("login");
            mv.addObject("msg", "Login Failed");
            return mv;
        } else {
            ModelAndView mv = new ModelAndView("home");
            mv.addObject("user", tmp);
            
            // Create a session and store user information
            HttpSession session = request.getSession();
            session.setAttribute("user", tmp);
            
            return mv;
        }
    }

    @GetMapping("/home")
    public ModelAndView home() {
        ModelAndView mv = new ModelAndView("home");
        return mv;
    }
    
    @GetMapping("/services")
    public ModelAndView services() {
        ModelAndView mv = new ModelAndView("services");
        return mv;
        
    }
    
    
    @GetMapping("/contact")
    public ModelAndView contact() {
        ModelAndView mv = new ModelAndView("contact");
        return mv;
        
    }
    
    
    @GetMapping("/acservice")
    public ModelAndView acservice() {
        ModelAndView mv = new ModelAndView("acservice");
        return mv;
        
    }
    
    @PostMapping("/bookingservice")
    public ModelAndView bookingService(HttpServletRequest request) {
        String[] services = request.getParameterValues("services");
        ModelAndView mv = new ModelAndView("bookingservice");
        mv.addObject("services", services != null ? Arrays.asList(services) : null);
        return mv;
    }
    
    @GetMapping("/logout")
    public String logout(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        redirectAttributes.addFlashAttribute("msg", "You have been successfully logged out.");
        return "redirect:/";
    }
    
    
 
   
    



    
}