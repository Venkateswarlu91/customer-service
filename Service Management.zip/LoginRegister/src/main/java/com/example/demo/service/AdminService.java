package com.example.demo.service;

import com.example.demo.model.Admin;

public interface AdminService {
    String register(Admin admin);
    Admin login(String email, String password);
    Admin updateAdmin(Admin admin);
    void deleteAdmin(int id);
}
