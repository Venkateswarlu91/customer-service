package com.example.demo.controller;

import com.example.demo.model.Admin;
import com.example.demo.model.User;
import com.example.demo.service.AdminService;
import com.example.demo.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private UserService userService;

    @GetMapping("/admin")
    public ModelAndView adminLogin(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("adminlogin");
        return mv;
    }

    @GetMapping("/admin/register")
    public ModelAndView adminRegister(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("adminregister");
        return mv;
    }

    @PostMapping("/admin/registerprocess")
    public ModelAndView adminAdd(HttpServletRequest request) {
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        Admin admin = new Admin();
        admin.setEmail(email);
        admin.setName(name);
        admin.setPassword(password);

        String str = adminService.register(admin);
        ModelAndView mv = new ModelAndView("adminlogin");
        mv.addObject("msg", str);
        return mv;
    }

    @PostMapping("/admin/loginprocess")
    public ModelAndView adminLoginProcess(HttpServletRequest request) {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Admin tmp = adminService.login(email, password);

        if (tmp == null) {
            ModelAndView mv = new ModelAndView("adminlogin");
            mv.addObject("msg", "Login Failed");
            return mv;
        } else {
            ModelAndView mv = new ModelAndView("adminhome");
            mv.addObject("admin", tmp);

            // Create a session and store admin information
            HttpSession session = request.getSession();
            session.setAttribute("admin", tmp);

            return mv;
        }
    }

    @GetMapping("/admin/home")
    public ModelAndView adminHome() {
        ModelAndView mv = new ModelAndView("adminhome");
        return mv;
    }

    @GetMapping("/admin/updateUser")
    public ModelAndView updateUser(@RequestParam int id) {
        User user = userService.findById(id);
        ModelAndView mv = new ModelAndView("update");
        mv.addObject("user", user);
        return mv;
    }

    @PostMapping("/admin/updateUserProcess")
    public ModelAndView updateUserProcess(HttpServletRequest request) {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String address = request.getParameter("address");

        User user = new User();
        user.setId(id);
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setAddress(address);

        userService.updateUser(user);

        ModelAndView mv = new ModelAndView("admin/home");
        mv.addObject("msg", "User updated successfully");
        return mv;
    }

    @GetMapping("/admin/deleteUser")
    public ModelAndView deleteUser(@RequestParam int id) {
        userService.deleteUser(id);
        ModelAndView mv = new ModelAndView("admin/home");
        mv.addObject("msg", "User deleted successfully");
        return mv;
    }

    @GetMapping("/admin/logout")
    public String adminLogout(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        redirectAttributes.addFlashAttribute("msg", "You have been successfully logged out.");
        return "redirect:/admin";
    }

    // Add a new method to get all users
    @GetMapping("/admin/users")
    public ModelAndView viewAllUsers() {
        List<User> users = userService.findAllUsers();
        ModelAndView mv = new ModelAndView("userlist");
        mv.addObject("users", users);
        return mv;
    }
}
